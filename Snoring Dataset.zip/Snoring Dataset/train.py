import os
import numpy as np
import librosa
import tensorflow as tf
from tensorflow.keras import layers, models
from sklearn.model_selection import train_test_split

snore_path = r'/Users/semanurcan/Downloads/Snoring Dataset/0'
non_snore_path = r'/Users/semanurcan/Downloads/Snoring Dataset/1'

sample_rate = 16000
duration = 1  # saniye
samples = sample_rate * duration

def load_data(folder, label):
    data = []
    for file in os.listdir(folder):
        if file.endswith('.wav'):
            path = os.path.join(folder, file)
            try:
                signal, sr = librosa.load(path, sr=sample_rate)
                if len(signal) == samples:
                    mel = librosa.feature.melspectrogram(y=signal, sr=sr, n_mels=40)
                    log_mel = librosa.power_to_db(mel, ref=np.max)
                    data.append((log_mel, label))
            except Exception as e:
                print(f"Hata: {file} - {e}")
    return data

print("Veriler yükleniyor...")
snore_data = load_data(snore_path, 1)
non_snore_data = load_data(non_snore_path, 0)
all_data = snore_data + non_snore_data
np.random.shuffle(all_data)

X = np.array([x[0] for x in all_data])
X = X[..., np.newaxis]  # CNN için (n, freq, time, 1)
y = np.array([x[1] for x in all_data])

X_train, X_val, y_train, y_val = train_test_split(X, y, test_size=0.2, random_state=42, stratify=y)

model = models.Sequential([
    layers.Conv2D(32, (3,3), activation='relu', input_shape=X_train.shape[1:]),
    layers.MaxPooling2D((2,2)),
    layers.Conv2D(64, (3,3), activation='relu'),
    layers.MaxPooling2D((2,2)),
    layers.Flatten(),
    layers.Dense(64, activation='relu'),
    layers.Dense(1, activation='sigmoid')
])

model.compile(optimizer='adam',
              loss='binary_crossentropy',
              metrics=['accuracy'])

print("Model eğitiliyor...")
model.fit(X_train, y_train, epochs=10, batch_size=32, validation_data=(X_val, y_val))

model.save("snoring_model.h5")
print("Model başarıyla kaydedildi: snoring_model.h5")
