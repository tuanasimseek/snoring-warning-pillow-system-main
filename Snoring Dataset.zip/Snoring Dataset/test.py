import sounddevice as sd
import numpy as np
import librosa
from tensorflow.keras.models import load_model

SR = 16000  
DURATION = 5  
MODEL_PATH = "snoring_model.h5"

model = load_model(MODEL_PATH)

def record_audio():
    print(f"🎤 {DURATION} saniyelik ses kaydediliyor...")
    audio = sd.rec(int(SR * DURATION), samplerate=SR, channels=1, dtype='float32')
    sd.wait()
    return audio.flatten()

# 🔍 Tahmin et (5 parçaya böl, her biri için ayrı tahmin al)
def predict(audio):
    predictions = []
    segment_length = SR  # 1 saniye = 16000 örnek
    for i in range(0, len(audio), segment_length):
        segment = audio[i:i + segment_length]
        if len(segment) == segment_length:
            mel = librosa.feature.melspectrogram(y=segment, sr=SR, n_mels=40)
            log_mel = librosa.power_to_db(mel, ref=np.max)
            log_mel = log_mel[np.newaxis, ..., np.newaxis]  # shape: (1, freq, time, 1)
            pred = model.predict(log_mel, verbose=0)[0][0]
            predictions.append(pred)
    if predictions:
        return np.mean(predictions)  # Ortalama tahmin skoru
    else:
        return 0.0  # Tahmin yapılamadıysa güvenli dönüş

print("Mikrofon aktif. Çıkmak için Ctrl+C.")

try:
    while True:
        audio = record_audio()
        if len(audio) == SR * DURATION:
            prediction = predict(audio)
            label = "HORLAMA" if prediction >= 0.5 else "HORLAMA DEĞİL"
            print(f"Tahmin: {label} (Güven: {prediction:.2f})")
        else:
            print(f"Ses uzunluğu eksik: {len(audio)} örnek kaydedildi, beklenen: {SR * DURATION}")
except KeyboardInterrupt:
    print("\nGerçek zamanlı test sonlandırıldı.")
